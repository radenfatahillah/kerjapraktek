<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/buku-index', 'BukuController@index')->name('bukuindex')->middleware('auth');
Route::get('/buku-show/{id}', 'BukuController@show')->name('bukushow')->middleware('auth');
Route::get('/buku-create', 'BukuController@create')->name('bukucreate')->middleware('auth');
Route::post('/buku-store', 'BukuController@store')->name('bukustore')->middleware('auth');
Route::delete('/buku-delete/{id}', 'BukuController@destroy')->name('bukudelete')->middleware('auth');
Route::get('/buku-edit/{id}', 'BukuController@edit')->name('bukuedit')->middleware('auth');
Route::patch('/buku-update/{id}', 'BukuController@update')->name('bukuupdate')->middleware('auth');