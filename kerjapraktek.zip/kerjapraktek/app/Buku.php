<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Buku extends Model
{
    public $timestamps = false;
    protected $table = 'buku';
    protected $id;
    protected $judul_buku;
    protected $penulis;
    protected $deskripsi;

    public static function ambilSemua()
    {
        return self::all();
    }

    public static function ambil($id)
    {
        return self::find($id);
    }

    public function tambah()
    {

    }
}
