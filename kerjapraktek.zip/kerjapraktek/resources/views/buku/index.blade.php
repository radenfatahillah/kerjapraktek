@extends('layouts.utama')
@section('active11')
Beranda
@endsection
@section('aktif1')
active
@endsection

@section('isi')

<table class="table">
    <tr>
        <th>No</th>
        <th>Judul Buku</th>
        <th>Penulis</th>
        <th>Deskripsi</th>
        <th>Aksi</th>
    </tr>
    <?php foreach ($buku as $bku): ?>
    <tr>
            <td><?= $bku->id ?></td>
            <td>
                <a href="<?= route('bukushow',['id'=>$bku->id]) ?>"><?= $bku->judul_buku ?></a></td>
            <td><?= $bku->penulis ?></td>
            <td><?= $bku->deskripsi ?></td>
            <td>

                <a href="<?= route('bukuedit',['id'=>$bku->id])?>" class="btn btn-sm btn-success">Edit</a>
                
                <form action="<?= route('bukudelete',['id'=>$bku->id]) ?>" method="POST">
                    @csrf
                    @method('DELETE')
                    <input type="submit" class="btn btn-sm btn-danger" value="Delete" >
                </form>
            </td>
    <?php endforeach ?>
    </tr> 
</table>    
@endsection