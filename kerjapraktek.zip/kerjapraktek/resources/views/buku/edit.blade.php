@extends('layouts.utama')
@section('active11')
Edit Buku
@endsection
@section('aktif1')
active
@endsection

@section('isi')


<form action="<?= route('bukuupdate',['id'=>$buku->id]) ?>" method="POST">
        @csrf
        @method('PATCH')
        <div class="form-group">
            <label for="judul_buku" class="form-control-label">Judul Buku</label>
            <?= $buku->nama_buku ?> 
            <input type="text" name="judul_buku" class="form-control" value="<?= $buku->judul_buku ?>">
        </div>
        <div class="form-group">
            <label for="penulis" class="form-control-label">Penulis</label>
            <?= $buku->nama_buku ?> 
            <input type="text" name="penulis" class="form-control" value="<?= $buku->penulis ?>">
        </div>
        <div class="form-group">
            <label for="deskripsi" class="form-control-label">Deskripsi</label>
            <?= $buku->nama_buku ?> 
            <textarea type="text" name="deskripsi" rows="4" class="form-control"><?= $buku->deskripsi ?></textarea>
        </div>
        <div class="form-group">
            <input type="submit" value="Kirim" class="btn btn-success">
        </div>

</form>
@endsection