@extends('layouts.utama')
@section('active11')
Tambah Buku
@endsection
@section('aktif3')
active
@endsection

@section('isi')

<form action="<?= route('bukustore') ?>" method="POST">
        @csrf
        <div class="form-group">
            <label for="judul_buku" class="form-control-label">Judul Buku</label>
            <input type="text" name="judul_buku" class="form-control">
        </div>
        <div class="form-group">
            <label for="penulis" class="form-control-label">Penulis</label>
            <input type="text" name="penulis" class="form-control">
        </div>
        <div class="form-group">
            <label for="deskripsi" class="form-control-label">Deskripsi</label>
            <textarea type="text" name="deskripsi" rows="4" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <input type="submit" value="Kirim" class="btn btn-success">
        </div>
</form>
@endsection