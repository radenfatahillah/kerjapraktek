@extends('layouts.utama')
@section('active11')
Halaman Detail
@endsection

@section('isi')
<blockquote class="blockquote text-justify">
    <h3 class="text-center">{{ $buku->judul_buku }}</h3>
    <hr>
	<p>{{ $buku->deskripsi }}</p>
	<footer class="blockquote-footer">Penulis : {{ $buku->penulis }}</footer>
</blockquote>
<a href="{{route('bukuindex')}}" class="btn btn-sm btn-success">Kembali</a>
@endsection