<div class="page-content d-flex align-items-stretch"> 
<nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/Logo-Untan-Universitas-Tanjungpura-PNG.png" alt="..." class="img-fluid"></div>
            <div class="title">
              <h1 class="h4">Kerja Praktek</h1>
              <p>Administrator</p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li class="@yield('aktif1')"><a href="{{route('bukuindex')}}"> <i class="icon-home"></i>Beranda </a></li>
            <li class="@yield('aktif3')"><a href="{{route('bukucreate')}}"> <i class="icon-padnote"></i>Tambah Buku </a></li>
        </nav>