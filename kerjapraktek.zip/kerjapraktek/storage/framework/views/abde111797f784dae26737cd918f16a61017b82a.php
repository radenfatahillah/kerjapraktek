<?php $__env->startSection('active11'); ?>
Tambah Buku
<?php $__env->stopSection(); ?>
<?php $__env->startSection('aktif3'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>

<form action="<?= route('bukustore') ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="judul_buku" class="form-control-label">Judul Buku</label>
            <input type="text" name="judul_buku" class="form-control">
        </div>
        <div class="form-group">
            <label for="penulis" class="form-control-label">Penulis</label>
            <input type="text" name="penulis" class="form-control">
        </div>
        <div class="form-group">
            <label for="deskripsi" class="form-control-label">Deskripsi</label>
            <textarea type="text" name="deskripsi" rows="4" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <input type="submit" value="Kirim" class="btn btn-success">
        </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/kerjapraktek/resources/views/buku/create.blade.php ENDPATH**/ ?>