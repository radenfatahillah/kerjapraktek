<?php $__env->startSection('active11'); ?>
Beranda
<?php $__env->stopSection(); ?>
<?php $__env->startSection('aktif1'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>

<table class="table">
    <tr>
        <th>No</th>
        <th>Judul Buku</th>
        <th>Penulis</th>
        <th>Deskripsi</th>
        <th>Aksi</th>
    </tr>
    <?php foreach ($buku as $bku): ?>
    <tr>
            <td><?= $bku->id ?></td>
            <td>
                <a href="<?= route('bukushow',['id'=>$bku->id]) ?>"><?= $bku->judul_buku ?></a></td>
            <td><?= $bku->penulis ?></td>
            <td><?= $bku->deskripsi ?></td>
            <td>

                <a href="<?= route('bukuedit',['id'=>$bku->id])?>" class="btn btn-sm btn-success">Edit</a>
                
                <form action="<?= route('bukudelete',['id'=>$bku->id]) ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" class="btn btn-sm btn-danger" value="Delete" >
                </form>
            </td>
    <?php endforeach ?>
    </tr> 
</table>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/kerjapraktek/resources/views/buku/index.blade.php ENDPATH**/ ?>