<?php $__env->startSection('active11'); ?>
Halaman Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
<blockquote class="blockquote text-justify">
    <h3 class="text-center"><?php echo e($buku->judul_buku); ?></h3>
    <hr>
	<p><?php echo e($buku->deskripsi); ?></p>
	<footer class="blockquote-footer">Penulis : <?php echo e($buku->penulis); ?></footer>
</blockquote>
<a href="<?php echo e(route('bukuindex')); ?>" class="btn btn-sm btn-success">Kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/kerjapraktek/resources/views/buku/show.blade.php ENDPATH**/ ?>