<?php $__env->startSection('active11'); ?>
Edit Buku
<?php $__env->stopSection(); ?>
<?php $__env->startSection('aktif1'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>


<form action="<?= route('bukuupdate',['id'=>$buku->id]) ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="form-group">
            <label for="judul_buku" class="form-control-label">Judul Buku</label>
            <?= $buku->nama_buku ?> 
            <input type="text" name="judul_buku" class="form-control" value="<?= $buku->judul_buku ?>">
        </div>
        <div class="form-group">
            <label for="penulis" class="form-control-label">Penulis</label>
            <?= $buku->nama_buku ?> 
            <input type="text" name="penulis" class="form-control" value="<?= $buku->penulis ?>">
        </div>
        <div class="form-group">
            <label for="deskripsi" class="form-control-label">Deskripsi</label>
            <?= $buku->nama_buku ?> 
            <textarea type="text" name="deskripsi" rows="4" class="form-control"><?= $buku->deskripsi ?></textarea>
        </div>
        <div class="form-group">
            <input type="submit" value="Kirim" class="btn btn-success">
        </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/kerjapraktek/resources/views/buku/edit.blade.php ENDPATH**/ ?>